<!DOCTYPE html>
<html lang = "en">
  <html>
    <head>
      <meta charset="utf-8">
      <link rel="stylesheet" href="mystyle.css"> 
      <! use mystyle.css>
    </head>
    <body onload='document.paymentForm.cardNumber.focus()'>
      <header>
        <h1>Payment options
        </h1>
      </header> 
      <h3>Debit/Credit Card
        </h4>
      <img src = "img/mastercard.svg" class="myImage">
      <br>
      <form action="/secondpage.php" name='paymentForm' class='form' method="post" >
        <label>Card number
        </label>
        <input type='text' name='cardNumber' size="20" placeholder ="5100000000000000">
        <br>
        <label>Expiration date
        </label>
        <input type="date" name='date' id= 'date' placeholder="yyyy/mm/dd">
        <br>
        <label>Security code
        </label>
        <input type="text" min="000" maxLength="9999" size = "8" name='code' id='code'>
        <p>(3-4 digit code normaly on the back of your card)
        </p>
        <input type="submit" name="submit" value="Continue" class="submit" onclick="return cardnumber(document.paymentForm.cardNumber)">  
        <! if cardnumber function returns true, then form is submitted>
        <! but if cardnumber() returns false, then user stay on the same page,becasue form is not submitted>
      </form>
      <script src="js/numberCheck.js">
      </script> 
      <! use to numberCheck.js >
    </body>
  </html>
  <?php
    $servername = "localhost";    //database details
    $username = "root";
    $password = "";
    $dbname = "creditcard";
    
    $conn = new mysqli($servername, $username, $password, $dbname);  //create connection
    mysqli_select_db($conn, 'creditcard');  //select database
    // Check connection
    if ($conn->connect_error) {  //if connecting fail, display error message
        die("Connection failed: " . $conn->connect_error);
    exit();
    } 
    $conn->close();  //close connection
?>

